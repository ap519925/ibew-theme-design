<?php

declare(strict_types=1);

namespace Drush\Sql;

class SqlException extends \Exception
{
}
