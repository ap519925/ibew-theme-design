---
edit_url: https://github.com/drush-ops/drush/blob/13.x/examples/example.drush.yml
---
```yaml
--8<-- "examples/example.drush.yml"
```
