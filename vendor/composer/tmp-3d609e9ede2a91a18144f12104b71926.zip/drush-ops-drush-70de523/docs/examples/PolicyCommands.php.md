---
edit_url: https://github.com/drush-ops/drush/blob/13.x/examples/Commands/PolicyCommands.php
---
```php
--8<-- "examples/Commands/PolicyCommands.php"
```
