<?php

namespace DoNotUse;

class Mixed
{
    public function __invoke(): string {
        return 'mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed mixed';
    }
}
