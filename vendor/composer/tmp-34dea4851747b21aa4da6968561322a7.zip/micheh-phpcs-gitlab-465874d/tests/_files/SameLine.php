<?php

namespace DoNotUse;

class SameLine
{
    public function __invoke(): string
    {
        return 'same'. 'line'. 'twice';
    }
}
