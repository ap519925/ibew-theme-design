<?php

namespace DoNotUse;

class Single
{
    public function __invoke(): string {
        return 'single';
    }
}
