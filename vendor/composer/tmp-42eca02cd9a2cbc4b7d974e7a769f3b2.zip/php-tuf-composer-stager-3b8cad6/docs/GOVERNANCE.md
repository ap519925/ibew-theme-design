# Project Governance

This project falls under Drupal core's governance. See https://git.drupalcode.org/project/governance/-/blob/main/README.md.
