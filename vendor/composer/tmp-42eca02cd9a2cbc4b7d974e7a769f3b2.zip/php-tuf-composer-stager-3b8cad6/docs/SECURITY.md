# Security Policy

DO NOT PUBLISH SECURITY REPORTS PUBLICLY.

Security advisories for this project are coordinated by the Drupal Security Team.

If you found any issues that might have security implications, please send a report to security[at]drupal.org

The full [Security Policy](https://www.drupal.org/drupal-security-team) is described in Drupal's official documentation.
