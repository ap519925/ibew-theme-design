## Complexity

#### SlevomatCodingStandard.Complexity.Cognitive

Enforces maximum [cognitive complexity](https://www.sonarsource.com/docs/CognitiveComplexity.pdf) for functions.

Sniff provides the following setting:

* `warningThreshold` (default: `6`)
* `errorThreshold` (default: `6`)
