# Changelog

### 2.0.3 - 2025/Nov/14

- PHP 8.5 support

### 2.0.2 - 2021/Dec/29

- Support logical operations with more than two operands
- PHP 8.1 support

### 2.0.0 - 2021/Mar/10

- PHP 8 support
- Drop older versions of PHP and Symfony

### 1.0.0 - 2019/Jan/17

Initial release
