<?php

namespace Http\Adapter\Guzzle7\Exception;

use Http\Client\Exception;

final class UnexpectedValueException extends \UnexpectedValueException implements Exception
{
}
