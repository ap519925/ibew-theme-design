<?php

declare(strict_types=1);

namespace mglaman\PHPStanDrupal\Type\EntityStorage;

final class ConfigEntityStorageType extends EntityStorageType
{

}
