---
name: Feature request
about: It'd be great if...
title: ''
labels: enhancement
assignees: ''

---

# Feature request

<!-- Please provide a clear description of what problem you are trying to solve and how would you want it to be solved. -->
