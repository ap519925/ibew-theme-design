<?php

declare(strict_types=1);

namespace JsonSchema;

abstract class Enum extends \MabeEnum\Enum
{
}
