<?php

namespace Behat\Mink;

final class KeyModifier
{
    public const CTRL = 'ctrl';
    public const ALT = 'alt';
    public const SHIFT = 'shift';
    public const META = 'meta';
}
