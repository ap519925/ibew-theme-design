<?php declare(strict_types=1);
namespace Nevay\SPI;

use Error;

final class ServiceConfigurationError extends Error {

}
